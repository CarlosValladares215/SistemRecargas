package com.mycompany.recargasproyectoex.clases;

public enum EstadoCelular {
    ACTIVO,
    INACTIVO,
    BLOQUEADO
}